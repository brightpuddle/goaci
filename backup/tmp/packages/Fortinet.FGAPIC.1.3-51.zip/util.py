import json
import sys
import Insieme.Logger
import Insieme.Config

Logger = Insieme.Logger


def get_interface_based_on_target_interface(
    device_type, dev_name, encapass, target_interface, vdom_name, device_dic
):
    # the interface can be internal, external, LAN and etc.
    Logger.log(Logger.DEBUG, "ENTER: %s" % (sys._getframe().f_code.co_name))
    Logger.log(Logger.DEBUG, "target_interface %s, vdom_name %s" % (
               target_interface, vdom_name))
    lpost_intf = ''
    intf_encap = ''
    # find the intf_encap
    for device_intf_item in device_dic['device_intf_list']:
        if device_intf_item['intf_target'] == target_interface:
            intf_encap = device_intf_item['intf_encap']
            break;
    if intf_encap == '':
        Logger.log(Logger.DEBUG, "EXIT: %s No intf_encap for %s" 
            % (sys._getframe().f_code.co_name, target_interface))
        return lpost_intf

    # Logger.log(Logger.DEBUG, 'encapass, %s' %(encapass))
    for encapass_key, encapass_value in encapass.items():
        '''
        if ((dev_name+'_'+target_interface) == encapass_value['vif'] and (
            encapass_value['vdom_name'] == vdom_name)
        ):
        '''
        if encapass_key == intf_encap:
            if device_type == 'VIRTUAL':
                lpost_intf = encapass_value['cif']
                break
            elif device_type == 'PHYSICAL':
                lpost_intf = encapass_value['cif']+'_v'+str(
                    encapass_value['tag']
                )
                break
            else:
                Logger.log(Logger.CRIT, "ERROR: no value device_type %s" % (
                           device_type))
                break
    Logger.log(Logger.DEBUG, "lpost_intf %s" % (lpost_intf))
    Logger.log(Logger.DEBUG, "EXIT: %s" % (sys._getframe().f_code.co_name))
    return lpost_intf

def get_interface_state_based_on_target_interface(
    device_type, dev_name, encapass, target_interface, vdom_name, device_dic
):
    state = 0 # UNCHANGED
    # the interface can be internal, external, LAN and etc.
    Logger.log(Logger.DEBUG, "ENTER: %s" % (sys._getframe().f_code.co_name))
    Logger.log(Logger.DEBUG, "target_interface %s, vdom_name %s" % (
               target_interface, vdom_name))
    # find the intf_encap
    for device_intf_item in device_dic['device_intf_list']:
        if device_intf_item['intf_target'] == target_interface:
            intf_encap = device_intf_item['intf_encap']
            break;
    if intf_encap == '':
        Logger.log(Logger.DEBUG, "EXIT: %s No intf_encap for %s" 
            % (sys._getframe().f_code.co_name, target_interface))
        return state

    # Logger.log(Logger.DEBUG, 'encapass, %s' %(encapass))
    for encapass_key, encapass_value in encapass.items():
        '''
        if ((dev_name+'_'+target_interface) == encapass_value['vif'] and (
            encapass_value['vdom_name'] == vdom_name)
        ):
        '''
        if encapass_key == intf_encap:
            state = encapass_value['state']
            break
    Logger.log(Logger.DEBUG, "target_interface %s state %s" % (target_interface, state))
    Logger.log(Logger.DEBUG, "EXIT: %s" % (sys._getframe().f_code.co_name))
    return state

def get_interface(
    device_type, encapass, grpid_interface_id_map,
    interface, grpid, vdom_name
):
    Logger.log(Logger.DEBUG, "ENTER: %s" % (sys._getframe().f_code.co_name))
    Logger.log(Logger.DEBUG, "interface %s, vdom_name %s" % (
               interface, vdom_name))
    Logger.log(Logger.DEBUG, "grpid = %s grpid_interface_id_map = %s" % (
               grpid, grpid_interface_id_map))
    lpost_intf = ''
    if (interface =='') or (interface == 'any'):
        lpost_intf = 'any'
        Logger.log(Logger.DEBUG, "lpost_intf %s" % (lpost_intf))
        Logger.log(Logger.DEBUG, "EXIT: %s" % (sys._getframe().f_code.co_name))
        return lpost_intf
    # Logger.log(Logger.DEBUG, 'encapass, %s' %(encapass))
    for encapass_key, encapass_value in encapass.items():
        intf_id = grpid_interface_id_map[grpid][interface]
        Logger.log(Logger.DEBUG, "intf_id %s" % (intf_id))
        if intf_id == encapass_key and (
            encapass_value['vdom_name'] == vdom_name
        ):
            if device_type == 'VIRTUAL':
                lpost_intf = encapass_value['cif']
                break
            elif device_type == 'PHYSICAL':
                lpost_intf = encapass_value['cif']+'_v'+str(
                    encapass_value['tag']
                )
                break
            else:
                Logger.log(Logger.CRIT, "ERROR: no value device_type %s" % (
                           device_type))
                break
    Logger.log(Logger.DEBUG, "lpost_intf %s" % (lpost_intf))
    Logger.log(Logger.DEBUG, "EXIT: %s" % (sys._getframe().f_code.co_name))
    return lpost_intf


def get_ospf_interface(
    device_type, encapass,
    intf_id, vdom_name
):
    Logger.log(Logger.DEBUG, "ENTER: %s" % (sys._getframe().f_code.co_name))
    Logger.log(Logger.DEBUG, "intf_id %s, vdom_name %s" % (
               intf_id, vdom_name))
    lpost_intf = ''
    # Logger.log(Logger.DEBUG, 'encapass, %s' %(encapass))
    if encapass.has_key(intf_id):
        Logger.log(Logger.DEBUG, "intf_id %s" % (intf_id))
        if encapass[intf_id]['vdom_name'] == vdom_name:
            if device_type == 'VIRTUAL':
                lpost_intf = encapass[intf_id]['cif']
            elif device_type == 'PHYSICAL':
                lpost_intf = encapass[intf_id]['cif']+'_v'+str(
                    encapass[intf_id]['tag']
                )
            else:
                Logger.log(Logger.CRIT, "ERROR: no value device_type %s" % (
                           device_type))
    Logger.log(Logger.DEBUG, "lpost_intf %s" % (lpost_intf))
    Logger.log(Logger.DEBUG, "EXIT: %s" % (sys._getframe().f_code.co_name))
    return lpost_intf

def get_ospf_interface_id(
    device_type, encapass,
    interface, vdom_name
):
    Logger.log(Logger.DEBUG, "ENTER: %s" % (sys._getframe().f_code.co_name))
    Logger.log(Logger.DEBUG, "interface %s, vdom_name %s" % (
               interface, vdom_name))
    intf_id = ''
    # Logger.log(Logger.DEBUG, 'encapass, %s' %(encapass))
    for encapass_key, encapass_value in encapass.items():
        intf_id = grpid_interface_id_map[grpid][interface]
        Logger.log(Logger.DEBUG, "intf_id %s" % (intf_id))
        Logger.log(Logger.DEBUG, "EXIT: %s" % (
                   sys._getframe().f_code.co_name))
        return intf_id
    Logger.log(Logger.DEBUG, "EXIT: %s no intf_id found for %s" % (
               sys._getframe().f_code.co_name, interface))
    return intf_id

def get_interface_id(
    device_type, encapass, grpid_interface_id_map,
    interface, grpid, vdom_name
):
    Logger.log(Logger.DEBUG, "ENTER: %s" % (sys._getframe().f_code.co_name))
    Logger.log(Logger.DEBUG, "interface %s, vdom_name %s" % (
               interface, vdom_name))
    intf_id = ''
    # Logger.log(Logger.DEBUG, 'encapass, %s' %(encapass))
    for encapass_key, encapass_value in encapass.items():
        intf_id = grpid_interface_id_map[grpid][interface]
        Logger.log(Logger.DEBUG, "intf_id %s" % (intf_id))
        Logger.log(Logger.DEBUG, "EXIT: %s" % (
                   sys._getframe().f_code.co_name))
        return intf_id
    Logger.log(Logger.DEBUG, "EXIT: %s no intf_id found for %s" % (
               sys._getframe().f_code.co_name, interface))
    return intf_id


def get_conn_state(device_dic, grpid, interface):
    Logger.log(Logger.DEBUG, "ENTER: %s" % (sys._getframe().f_code.co_name))
    conn_device_state = ''
    if interface == "internal":
        conn_device_state = device_dic['grpid_interface_id_map'][
            grpid
        ]['connector_int_state']
    elif interface == "external":
        conn_device_state = device_dic['grpid_interface_id_map'][
            grpid
        ]['connector_ext_state']
    else:
        Logger.log(
            Logger.CRIT,
            "ERROR: invalid interface %s not (internal or external )" % (
                interface
            )
        )
    Logger.log(Logger.DEBUG, "conn_device_state %s" % (conn_device_state))
    Logger.log(Logger.DEBUG, "EXIT: %s" % (sys._getframe().f_code.co_name))
    return conn_device_state

# need to read all the interfaces, policies or static routes and etc. first
#
def read_from_apic_for_exist_item(fgt, url, vdom_name):
    Logger.log(Logger.DEBUG, "ENTER: %s" % (sys._getframe().f_code.co_name))
    exist_item = []
    response = fgt.get(url, params={'vdom': vdom_name})
    rest = []
    if response.status_code == 200:
        rest = response.json()['results']
    for res in rest:
        if 'interface' in url:
            if res['vdom'] == vdom_name:
                exist_item.append(res['name'])
        elif 'policy' in url:
            exist_item.append(str(res['policyid']))
        elif 'static' in url:
            exist_item.append(str(res['seq-num']))
        else:
            exist_item.append(res['name'])
    Logger.log(Logger.DEBUG, "EXIT: %s" % (sys._getframe().f_code.co_name))
    return exist_item


def compare_params_dic(result, new_params_dic):
    Logger.log(Logger.DEBUG, "ENTER: %s" % (sys._getframe().f_code.co_name))
    res_json = json.loads(result.text)
    # remove the empty, list and dict
    params_dic_rm_empty = {
        k: v for (k, v) in new_params_dic.items() if ((v != '') and
            (type(v) != list and type(v) != dict))
    }

    result_filter = {
        k: v for (k, v) in res_json['results'][0].items() if (
            type(v) != list and type(v) != dict)
    }
    if set(params_dic_rm_empty.items()).issubset(result_filter.items()):
        Logger.log(Logger.DEBUG, 'Audit called, no object '
                   'info needs to be updated.')
        Logger.log(Logger.DEBUG, "EXIT: %s" % (
                   sys._getframe().f_code.co_name))
        return True
    else:
        Logger.log(Logger.DEBUG, 'Objects info needs to be updated.')
        Logger.log(Logger.DEBUG, "EXIT: %s" % (
                   sys._getframe().f_code.co_name))
        return False


def compare_policy_params_dic(result, new_params_dic):
    Logger.log(Logger.DEBUG, "ENTER: %s" % (sys._getframe().f_code.co_name))
    res_json = json.loads(result.text)
    if 'results' in res_json.keys():
        res_text = res_json['results'][0]
    else:
        Logger.log(Logger.CRIT, 'ERROR: Requests failure - no results')
        return True
    params_dic_rm_empty = {
        k: v for (k, v) in new_params_dic.items() if v != ''
    }
    for key, value in params_dic_rm_empty.items():
        if isinstance(value, list):
            for params_item in value:
                for result_item in res_text[key]:
                    if set(params_item.items()).issubset(
                        result_item.items()
                    ) is not True:
                        Logger.log(
                            Logger.DEBUG,
                            'Policy needs to be updated.'
                        )
                        Logger.log(Logger.DEBUG, "EXIT: %s" % (
                                   sys._getframe().f_code.co_name))
                        return False
        elif isinstance(value, dict):
            for params_key, params_value in value.items():
                for res_key, res_value in res_text[key].items():
                    if params_key == res_key:
                        if params_value != res_value:
                            Logger.log(
                                Logger.DEBUG,
                                'Interface ip needs to be updated.'
                            )
                            Logger.log(Logger.DEBUG, "EXIT: %s" % (
                                       sys._getframe().f_code.co_name))
                            return False
        else:
            if res_json['results'][0][key] != value:
                Logger.log(Logger.DEBUG, 'Policy needs to be updated.')
                Logger.log(Logger.DEBUG, "EXIT: %s" % (
                           sys._getframe().f_code.co_name))
                return False
    Logger.log(Logger.DEBUG, 'Audit called, '
               'no policy info needs to be updated.')
    Logger.log(Logger.DEBUG, "EXIT: %s" % (sys._getframe().f_code.co_name))
    return True


def get_target_name(full_name):
    Logger.log(Logger.DEBUG, "ENTER: %s" % (sys._getframe().f_code.co_name))
    name_list = full_name.split('/')
    return name_list[-1]
    Logger.log(Logger.DEBUG, "EXIT: %s" % (sys._getframe().f_code.co_name))



